jQuery(function($)
{
  $.HelloToken(HelloToken);
});
