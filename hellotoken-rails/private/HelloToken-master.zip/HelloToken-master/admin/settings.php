<?php if (!defined('ABSPATH')) die(); ?>

<div class="wrap">
  <div class="settings-area">
    <h2>
      <?php esc_html_e('hellotoken: Ask Survey Questions or Monetize with Them', self::ld); ?>
      <span><?php esc_html_e("To activate, click the \"Activate with hellotoken\" option when composing a new post.", self::ld); ?></span>
    </h2>
    <div id="htform"></div>
    <br />
    <p class="submit">
      <?php submit_button(__('Save Changes', self::ld), 'primary', 'save_settings', false); ?>
      <span class="save_message"><?php _e('Settings saved.', self::ld); ?></span>
      <span class="spinner"></span>
      <br class="clear" />
    </p>
  </div>
</div>