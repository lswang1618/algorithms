jQuery(function($)
{
  var post_type_noun = (HelloToken.post_type == "page")? "Pages" : "Posts";
  var ht_toggle_category_id = 0;

  var $inlineedit = $('#inlineedit'),
    $checkbox_group = $('.inline-edit-col-right .inline-edit-group', $inlineedit).first(),
    $bulkedit = $('#bulk-edit'),
    $save_button_bulk = $('#bulk_edit', $bulkedit),
    $bulk_group = $('.inline-edit-col-right .inline-edit-col', $bulkedit),
    $inline_author = $('.inline-edit-author', $bulk_group),
    $pub_actions = $('#misc-publishing-actions');

  // create monetize label
  var $monetize_label = $('<label class="alignleft" style="margin-left: .5em;"></label>'),
    $monetize_checkbox = $('<input type="checkbox" name="ht-monetize" value="1"/>'),
    $monetize_title = $('<span class="checkbox-title" style="margin-left: 2px; font-weight: bold;"></span>').text(HelloToken.text.monetize_with_ht);

  $monetize_label.append($monetize_checkbox).append($monetize_title);

  // add monetize checkbox to post inline edit form
  if ($inlineedit.length > 0)
  {
    $checkbox_group.append($monetize_label.clone());

    function init_inlineedit()
    {
      var $inline_link = $('#the-list a.editinline:not(.ht_inline)');

      $inline_link.addClass('ht_inline').on('click', function()
      {
        // Get the row, the number of the row (i.e. post), and the corresponding hidden value
        // Disregard absolutely terrible naming of hellotoken_, ht-, and ht_
        // It's the shitty naming of the person before me, and I haven't changed it yet for fear
        // of breaking something else
        var $row = $(this).closest('tr'),
          post_id = $row.attr('id').split('-')[1],
          $hidden = $('input[name=hellotoken_monetize]', $row),
          waitForElements = function()
        {
          var $edit_row = ('#edit-' + post_id),
            $checkbox = $('input[name=ht-monetize]', $edit_row);

          if ($checkbox.length == 0)
            window.setTimeout(waitForElements, 200);
          else
          {
            var current_val = $hidden.val();
            // Set the checkbox based on the value of the hidden element (tracked further in hellotoken.php)
            $checkbox.attr('checked', $hidden.val() == 1?true:false).on('click', function()
            {
              // Appropriately change value based on check/un-check
              current_val = $checkbox.prop('checked')?1:0;
              $hidden.val(current_val);
            });

            $('a.save', $edit_row).on('click', function()
            {
              $.post(HelloToken.action_url, {
                post_id: post_id,
                monetize: current_val
              }, function(r) {console.log(r)});
            });
          }
        }
        waitForElements();
      });
    }

    // accepts a string or an int
    // '1'/1 for on, '0'/0 for off
    function toggle_all_ht(on_or_off){
      console.log(ht_toggle_category_id);

      $toggle_button = (on_or_off == '1')? $('#ht-enable-all') : $('#ht-disable-all');
      var button_message = (on_or_off == '1')? "Enable" : "Disable";
      var confirm_message = (on_or_off == '1')? "enabled." : "disabled.";
      $toggle_button.val('Toggling...');
      $toggle_button.prop('disabled', true);
      var category_name = (ht_toggle_category_id != 0) ? $('select[name=cat]').find(":selected").text():'All';

      $.post(HelloToken.action_url, {
        toggle_all_ht: on_or_off,
        post_type: HelloToken.post_type,
        category_id: ht_toggle_category_id
      }, function(r){
        if (r.status === 1){
          // hidden fields
          $('input[name=hellotoken_monetize]').each(function(index){
            $(this).val(parseInt(on_or_off));
          });
          // actual checkboxes
          $('input[name=ht-monetize]').each(function(index){
            $(this).attr('checked', on_or_off == '1'?true:false);
          });

          $('#ht-toggle-message').text(category_name + ' ' + HelloToken.post_type + 's ' + confirm_message);            
          $('#ht-toggle-message').show();
          window.setTimeout(function()
          {
            $('#ht-toggle-message').fadeOut(700);
          }, 2500);
        }
        else{
          $('#ht-toggle-message').show();
          $('#ht-toggle-message').text('Error while toggling. Please try again.');
        }
      });

      $("#ht-enable-all").val("Enable ht On " + category_name + " Posts");
      $("#ht-disable-all").val("Disable ht On " + category_name + " Posts");
      $toggle_button.prop('disabled', false);
    }

    $(document).ajaxStop(init_inlineedit);

    init_inlineedit();

    // a cheap tactic to try and add some buttons on the edit page only by leeching on this if statement
    // ideal would be to generate a new if-statement
    // I tried adding a new php hook, but I don't think the right one exists--you'd have to use JS eventually, anyways
    $('.wrap h2 .add-new-h2').after('<input type="button" class="add-new-h2 ht-button ht-toggle" id="ht-enable-all" value="Enable ht On All ' + post_type_noun + '" >');
    $('#ht-enable-all').on('click', function(){
      toggle_all_ht('1');
    });
    $('#ht-enable-all').after('<input type="button" class="add-new-h2 ht-button ht-toggle" id="ht-disable-all" value="Disable ht On All ' + post_type_noun + '" >');
    $('#ht-disable-all').on('click', function(){
      toggle_all_ht('0')
    });

    $('#ht-disable-all').after('<span id="ht-toggle-message"></span>');

    // WARNING: really hacky shit used to add category selecting to posts
    if(HelloToken.post_type != 'page'){
      var $category_select = $('select[name=cat]');
      var current_category = $('select[name=cat]').find(":selected").text();

      $category_select.change(function(){
        new_category_selection = $(this).find(":selected");
        ht_toggle_category_id = new_category_selection.val();

        if (ht_toggle_category_id != 0){
          $("#ht-enable-all").val("Enable ht On " + new_category_selection.text() + " Posts");
          $("#ht-disable-all").val("Disable ht On " + new_category_selection.text() + " Posts");
        }
        else{
          $("#ht-enable-all").val("Enable ht On All Posts");
          $("#ht-disable-all").val("Disable ht On All Posts");          
        }
      });

      $category_select.change(); // trigger a change at the beginning so the right text and category are set
      // So I had a lot of trouble finding a semi-clean way to toggle checkboxes based on the category
      // It's easy when I can just go through all of them and mass change them, but less so when I need a way to filter
      // The easy way is to just give up the nice changing button on every input change and only do it when
      // the category is actually reloaded by clicking the "filter" button
      // so here I trigger the change once for when the page loads and then immediately unbind it
      // comment this line if you find a way to filter by category
      $category_select.off("change");
    }
  }

  // bulk inline edit form
  if ($bulkedit.length > 0)
  {
    var $author = $inline_author.clone(true).removeClass('inline-edit-author').addClass('alignleft');
    $inline_author.remove();

    $bulk_group.prepend($('<div class="inline-edit-group"></div>').append($author).append($monetize_label.clone().removeClass('alignleft').addClass('alignright')));
  }

  // add checkbox to add/edit post page
  if ($pub_actions.length > 0)
  {
    var $label = $monetize_label.clone(),
      $checkbox = $('input[type=checkbox]', $label),
      $monetize_hidden = $('input[name=hellotoken_monetize]');

    // Set the checkbox based on the value of the hidden element (tracked further in hellotoken.php) and then listen for change
    $checkbox.attr('checked', $monetize_hidden.val() == 1?true:false).on('change', function()
    {
      // Appropriately change value based on check/un-check
      $monetize_hidden.val($checkbox.prop('checked')?1:0);
    });

    $('<div class="misc-pub-section"></div>').append($label.css('margin-left', '0')
      .css('margin-top', '2px').removeClass('alignleft')).appendTo($pub_actions);
  }

});