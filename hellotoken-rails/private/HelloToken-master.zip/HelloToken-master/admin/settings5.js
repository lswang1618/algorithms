jQuery(function($)
{
  // ease of development
  var currentHost = window.location.hostname;
  var pluginURL = (currentHost === 'localhost') ? 'http://localhost:3000' : 'https://hellotoken.com';

  var $spinner = $('.spinner'),
    $preview_button = $('input[name=preview_button]'),
    $save_button = $('input[name=save_settings]'),
    $save_message = $('.save_message'),
    $form = $('#htform');

  function getBasename(url)
  {
    return url.substr(url.lastIndexOf('/') + 1);
  }


  // init settings form
  $form.HTForm({
    settings: HelloToken.settings,
    texts: HelloToken.texts,
    onInit: function()
    {
      var form = this;
      // add company logo selector from wordpress
      // $('<input type="button" class="button button-secondary" name="logo_selector" value="' + HelloToken.text.please_select + '" /> <a href="" class="logo_filename" target="_blank"></a>')
      //   .insertAfter(form.form.company_logo.attr('type', 'hidden'));

      // var logo_selector = wp.media({
      //   title: HelloToken.text.media_upload_title,
      //   library: { type: 'image' },
      //   multiple: false
      // }),
      //   $logo_filename = $('.logo_filename'),
      //   url = form.form.company_logo.val();

      // $logo_filename.text(getBasename(url)).attr('href', url);

      // logo_selector.on('select', function()
      // {
      //   var image = logo_selector.state().get('selection').first().toJSON();

      //   form.form.company_logo.val(image.url);
      //   $logo_filename.text(getBasename(image.url)).attr('href', image.url);
      // });

      // $('input[name=logo_selector]').on('click', function()
      // {
      //   logo_selector.open();
      // });

      // preview
      $preview_button.on('click', function()
      {
        if (!form.doValidation())
          return;

        var code = '(function($) { ' + form.getCode({ preview: true }) + ' })(jQuery)';

        $('<script></script>').text(code).appendTo($('body'));

        return false;
      });
    }
  });


  // save settings
  function showLoader(v)
  {
    if (v)
      $spinner.show();
    else
      $spinner.hide();

    $save_button.attr('disabled', v);
  }

  $save_button.on('click', function(e)
  {
    e.preventDefault();

    if (!$form.HTForm('doValidation'))
      return;

    var alpha_id = $form.HTForm('getClient');

    $.ajax({
      url: pluginURL + "/popup/check",
      method: "GET",
      dataType: "JSONP",
      data:{
          "publisher_alpha_id": alpha_id, // clientID
          "publisher_url": window.location.href
      },
      success: function(data){
        if (data){
          showLoader(true);
          $.post(HelloToken.action_url, $form.HTForm('getSettings'), function(r){
            showLoader(false);

            $save_message.show();
            window.setTimeout(function()
            {
              $save_message.fadeOut(700);
            }, 2500);
          }).error(function()
          {
            showLoader(false);
          });
        }
        else{
          // If bad clientID, we do not plugin activation.
          console.log("HT: Bad ClientID. Save aborted.");
        }
      },
      error: function(data){
        console.log("HT: Couldn't save data. Aborted.");
      }
    });


    return false;
  });

});
