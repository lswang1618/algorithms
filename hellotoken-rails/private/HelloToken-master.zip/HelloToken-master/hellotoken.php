<?php
/*
Plugin Name: hellotoken
Plugin URI: http://wordpress.org/plugins/hellotoken/
Description: Beautifully ask readers questions and/or earn cold hard cash for each user that visits your site.
Version: 1.35
Author: hellotoken.com
Author URI: http://hellotoken.com
License: GPLv2 or later
Text Domain: hellotoken
*/

if (!defined('ABSPATH')) die();

class HelloToken
{
  // version of the plugin should be updated with header version
  const version = '1.35';

  // language domain, used for translation
  const ld = 'hellotoken';
  const nonce = 'hellotoken-nonce';

  private $_url, $_path, $settings;

  protected $default_settings;

  public function __construct()
  {
    // paths
    $this->_url = plugins_url('', __FILE__);
    $this->_path = dirname(__FILE__);

    // default settings definition, will be used as initial settings
    $this->default_settings = array(
      'homepage_url' => get_site_url(),
      'company_name' => '',
      'company_logo' => '',
      'client_id' => '',
      'free_content_count' => '0',
      'question' => '',
      'button_color' => '#f7931a',
      'button_text_color' => '#ffffff',
      'show_delay' => 0,
      'is_demo' => 0,
      'redirect_type' => '0', // 0 - do nothing, 1 - home page, 2 - custom url
      'redirect_url' => '',
      'default_enable' => '1', // 0 - new articles auto disabled, 1 - auto enabled
    );

    $this->settings = get_option(__class__.'_settings', $this->default_settings);

    // called to load appropriate language file
    add_action('plugins_loaded', array($this, 'plugins_loaded'));

    // add actions for the admin backend
    if (is_admin())
    {
      add_action('admin_menu', array($this, 'admin_menu'));
      add_action('wp_ajax_'.__class__, array($this, 'ajax_action'));

      // add scripts on the settings page
      add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));

      // alter post add/edit form
      add_action('edit_form_after_title', array($this, 'alter_post_edit_form'));

      // alter post row actions to handle monetize status
      add_filter('post_row_actions', array($this, 'alter_post_row_actions'), 10, 2);
      add_filter('page_row_actions', array($this, 'alter_post_row_actions'), 10, 2);

      // alter category edit page
      add_action('category_edit_form', array($this, 'alter_category_edit_form'));

      // save post data - eg. status for post
      add_action('save_post', array($this, 'save_post'));
    }
    else
    {
      // frontend integration
      if (isset($this->settings['homepage_url']) && $this->settings['homepage_url'])
      {
        // add hellotoken script file
        add_action('wp_enqueue_scripts', array($this, 'wp_enqueue_scripts'));

        // filter requests to catch query
        add_filter('request', array($this, 'filter_request'));
      }
    }

    // on activation and uninstallation (this hook must bind to a static method)
    register_activation_hook(__FILE__, array($this, 'activation'));
    register_uninstall_hook(__FILE__, array(__class__, 'uninstall'));
  }

  // on activation
  public function activation()
  {
    add_option(__class__.'_settings', $this->default_settings);
  }

  // on uninstallation
  static function uninstall()
  {
    delete_option(__class__.'_settings');
  }

  // when all plugins are loaded
  public function plugins_loaded()
  {
    load_plugin_textdomain(self::ld, false, dirname(plugin_basename(__FILE__)).'/languages/');
  }

  // add submenu item to the settings menu
  public function admin_menu()
  {
    add_options_page(__('hellotoken', self::ld), __('hellotoken', self::ld), 'manage_options', __class__, array($this, 'settings_page'));
    add_filter('plugin_action_links_'.plugin_basename(__FILE__), array(&$this, 'filter_plugin_actions'), 10, 2);
  }

  // add a shortcut to the settings page on the plugins page
  public function filter_plugin_actions($l, $file)
  {
    $settings_link = '<a href="options-general.php?page='.__class__.'">'.__('Settings').'</a>';
    array_unshift($l, $settings_link);
    return $l;
  }

  // enqueue scripts and styles
  public function admin_enqueue_scripts($hook)
  {
    $screen = get_current_screen();

    if ($hook == 'settings_page_'.__class__)
    {
      add_thickbox();
      wp_enqueue_media();

      // color picker
      // wp_enqueue_style(__class__.'_colorpicker', $this->_url.'/form/3rdparty/jquery-minicolors/jquery.minicolors.css', array(), self::version, 'all');
      // wp_enqueue_script(__class__.'_colorpicker', $this->_url.'/form/3rdparty/jquery-minicolors/jquery.minicolors.min.js', array('jquery'), self::version, false);

      // form
      wp_enqueue_style(__class__.'_form', $this->_url.'/form/form.css', array(), self::version, 'all');
      wp_enqueue_script(__class__.'_form', $this->_url.'/form/form5.js', array('jquery'), self::version, false);
      
      // settings
      wp_enqueue_style(__class__.'_styles', $this->_url.'/admin/settings.css', array(), self::version, 'all');
      wp_enqueue_script(__class__, $this->_url.'/admin/settings5.js', array('jquery'), self::version, false);

      // hellotoken
      wp_enqueue_script(__class__.'_hellotoken', $this->_url.'/hellotoken/hellotoken32.js', array('jquery'), self::version, false);
      // wp_enqueue_script(__class__.'_parse', $this->_url.'/3rdparty/parse.js', array('jquery'), self::version, false);
      wp_enqueue_script(__class__.'_analytics', $this->_url.'/3rdparty/analytics.js', array('jquery'), self::version, false);
      // wp_enqueue_script(__class__.'_ht', $this->_url.'/hellotoken/ht.js', array('jquery'), self::version, false);

      // this is a regular way how to pass variables from PHP to Javascript
      wp_localize_script(__class__, __class__, array(
        'action_url' => admin_url('admin-ajax.php?action='.__class__),
        'settings' => get_option(__class__.'_settings', $this->default_settings),
        'texts' => array(
          'connect' => __('Connect', self::ld),
          'your_homepage' => __('Your Homepage', self::ld),
          'here' => __('here', self::ld),
          'optional' => __('Optional', self::ld),
          'customize' => __('Customize', self::ld),
          'monetize' => __('Monetize', self::ld),
          'company' => __('Company', self::ld),
          'company_logo' => __('Company Logo', self::ld),
          'please_select' => __('Please select', self::ld),
          'free_content_count' => __('Free Content Count', self::ld),
          'free_content_count_desc' => __('Number of articles user has to click before the hellotoken dialog box is shown.', self::ld),
          'button_color' => __('Button Color', self::ld),
          'button_text_color' => __('Button Text Color', self::ld),
          'sign' => __('$', self::ld),
          'show_delay' => __('Paywall show delay', self::ld),
          'show_delay_desc' => __('Delay showing the paywall by a specified amount of time. By default the paywall is shown immediately.', self::ld),
          'seconds' => __('second(s)', self::ld)
        ),
        'text' => array(
          'ajax_error' => __('An error occurred during the AJAX request, please try again later.', self::ld),
          'media_upload_title' => __('Please select company logo', self::ld),
          'please_select' => __('Please select', self::ld)
        )
      ));
    }
    else
    if (($hook == 'edit.php' || $hook == 'post-new.php' || $hook == 'post.php') && in_array($screen->post_type, array('page', 'post')))
    {
      wp_enqueue_style(__class__.'_styles', $this->_url.'/admin/postedit.css', array(), self::version, 'all');
      wp_enqueue_script(__class__, $this->_url.'/admin/postedit.js', array('jquery'), self::version, false);
      wp_localize_script(__class__, __class__, array(
        'action_url' => admin_url('admin-ajax.php?action='.__class__),
        'text' => array(
          'monetize_with_ht' => __('Activate with hellotoken', self::ld)
        ),
        'post_type' => $screen->post_type
      ));
    }
  }

  // helper function to get setting if exists and if not then return default
  protected function getSetting($name)
  {
    if ($name=="choices")
      return $this->settings[$name];
    if (isset($this->settings[$name])){
      return self::strip(stripslashes($this->settings[$name]));
    }

    return $this->default_settings[$name];
  }

  // page to show settings in the admin backend
  public function settings_page()
  {
    require_once $this->_path.'/admin/settings.php';
  }

  // handle admin ajax actions
  public function ajax_action()
  {
    header('Content-Type: application/json');

    // save settings form
    if (isset($_POST['homepage_url']))
      update_option(__class__.'_settings', $_POST);

    // save monetize option per post
    if (isset($_POST['monetize']) && isset($_POST['post_id']) && $_POST['post_id'])
    {
      update_post_meta($_POST['post_id'], '_hellotoken', $_POST['monetize']);
      echo json_encode(array('status' => 1));
    }
    
    if (isset($_POST['toggle_all_ht'])){
      $opposite_status = ($_POST['toggle_all_ht'] == "1" ? "0" : "1"); // stupid, but works
      $this->alter_ht_status($this->get_ht_posts($opposite_status,$_POST['post_type'],$_POST['category_id']),$_POST['toggle_all_ht']);
      echo json_encode(array('status' => 1));
    }
    exit;
  }

  // filter requests to catch query
  public function filter_request($vars)
  {
    // create invoice method
    if (isset($_GET['method']) && $_GET['method'] == 'createInvoice' && isset($_GET['price']) &&
      isset($_GET['currency']) && isset($_GET['callback']) && isset($_GET['redirect']))
    {
      $r = wp_remote_post('https://'.$this->getSetting('bitpay_apikey').'@bitpay.com/api/invoice', array(
        'method' => 'POST',
        'timeout' => 45,
        'redirection' => 5,
        'httpversion' => '1.0',
        'blocking' => true,
        'headers' => array(
          'Content-Type' => 'application/json'
        ),
        'body' => json_encode(array(
          'price' => $_GET['price'],
          'currency' => $_GET['currency'],
          'transactionSpeed' => 'high',
          'redirectURL' => $_GET['redirect']
        )),
        'cookies' => array(),
        'sslverify' => false
      ));

      if (!is_wp_error($r))
        echo $_GET['callback'].'('.$r['body'].')';

      exit;
    }

    // check invoice
    if (isset($_GET['method']) && $_GET['method'] == 'checkInvoice' && isset($_GET['id']) && isset($_GET['callback']))
    {
      $r = wp_remote_get('https://'.$this->getSetting('bitpay_apikey').'@bitpay.com/api/invoice/'.$_GET['id'], array(
        'method' => 'GET',
        'timeout' => 45,
        'redirection' => 5,
        'httpversion' => '1.0',
        'blocking' => true,
        'headers' => array(),
        'body' => false,
        'cookies' => array(),
        'sslverify' => false
      ));

      if (!is_wp_error($r))
        echo $_GET['callback'].'('.$r['body'].')';

      exit;
    }

    return $vars;
  }

  // alter post add/edit form
  public function alter_post_edit_form($post)
  {
    if ($post && in_array($post->post_type, array('post', 'page')))
    {
      $state = get_post_meta($post->ID, '_hellotoken', true);
      $screen = get_current_screen();
      // Blank string is default value i.e. when never set before
      // Use strict comparison since otherwise would be confused with 0 
      if ($state === ""){
        // If we're on an "add post" page
        if ($screen->action == "add")
          $state = $this->getSetting("default_enable"); // go by settings
        else
          $state = "0"; // default to not active for other posts (i.e. posts created before HT installed)
      }
      echo '<input type="hidden" name="hellotoken_monetize" value="'.$state.'" />';
    }
  }

  // alter post row actions - add info about monetize for listed post (in each row)
  public function alter_post_row_actions($actions, $post)
  {
    if (in_array($post->post_type, array('post', 'page')))
    {
      $state = get_post_meta($post->ID, '_hellotoken', true);
      // Blank string is default value i.e. when never set before
      // Use strict comparison since otherwise would be confused with 0 
      if ($state === ""){
        // if (($post->post_type) === 'post'){
        //   $state = "1"; // Enable for posts by default
        // }
        // else{
        //   $state = "0"; // Disable for pages by default
        // } 
        $state = "0";
      }
      $actions = array_merge(array(
        'hellotoken_hidden' => '<input type="hidden" name="hellotoken_monetize" value="'.$state.'" />'
      ), $actions);
    }

    return $actions;
  }

  public function alter_category_edit_form($category){
  }

  // save post data - eg. status of for saved post
  public function save_post($post_id)
  {
    // perform bulk actions
    if (isset($_GET['bulk_edit']) && isset($_GET['post']) && is_array($_GET['post']))
    {
      foreach($_GET['post'] as $id)
        update_post_meta($id, '_hellotoken', isset($_GET['hellotoken-monetize'])?1:0); // notice hyphen instead of underscore
    }

    if (!(in_array($_POST['post_type'], array('post', 'page')) && current_user_can('edit_post', $post_id)))
      return;

    // 1 enabled, 0 disabled
    if (isset($_POST['hellotoken_monetize'])){
      // does nothing because it uses hellotoken_monetize and not ht-monetize
      // which is good b/c ajax_action already takes care of it
      // don't ask me what shrooms the guy who wrote this was on
      update_post_meta($post_id, '_hellotoken', $_POST['hellotoken_monetize']);
    }
  }


  // add scripts to the frontend
  public function wp_enqueue_scripts()
  {
    global $post;

    // only if is enabled for this post or page
    // post_meta uses strict comparison, since default for the meta is a blank string

    if(is_home() || // Don't show on home page
      (!is_single() && !is_page()) || // Don't show on non posts/pages
      (is_single() && get_post_meta($post->ID, '_hellotoken', true) !== "1") || // Don't show by default, but do if activated
      (is_page() && get_post_meta($post->ID, '_hellotoken', true) !== "1")) // Don't show by default, but do if activated
      {return;}

    // add main script
    // TODO set minified version
    wp_enqueue_script(__class__.'_jq', $this->_url.'/form/jquery.min.js', array('jquery'), self::version, false);
    wp_enqueue_script(__class__.'_hellotoken', $this->_url.'/hellotoken/hellotoken32.js', array('jquery'), self::version, false);
    wp_enqueue_script(__class__.'_analytics', $this->_url.'/3rdparty/analytics.js', array('jquery'), self::version, false);

    $site_url = trailingslashit(get_site_url());

    wp_enqueue_script(__class__, $this->_url.'/hellotoken.js', array('jquery'), self::version, false);
    
    wp_localize_script(__class__, __class__, array(
      'company' => $this->getSetting('company_name'),
      'logo' => $this->getSetting('company_logo'),
      'clientID' => $this->getSetting('client_id'),
      'numberClickedNeedBuy' => $this->getSetting('free_content_count'),
      'question' => $this->getSetting('question'),
      'homeLink' => $this->getSetting('homepage_url'),
      'buttonColor' => $this->getSetting('button_color'),
      'buttonTextColor' => $this->getSetting('button_text_color'),
      'showDelay' => (int)$this->getSetting('show_delay'),
      'is_demo' => $this->getSetting('is_demo'),
      'redirect_type' => $this->getSetting('redirect_type'),
      'redirect_url' => $this->getSetting('redirect_url'),
      'default_enable' => $this->getSetting('default_enable'),
    ));
  }

  public function alter_ht_status($posts, $status){
    foreach($posts as $post){
      update_post_meta($post->ID, '_hellotoken', $status);
    }
  }

  // helper strip function
  static function strip($t)
  {
    return htmlentities($t, ENT_COMPAT, 'UTF-8');
  }

  /**
   * get all posts from a category with a certain ht_state
   * -1 or empty for category to get all posts
   * ht_state should be 0 (currently off) or 1 (currently on)
   */
  static function get_ht_posts($ht_state, $post_type = 'post', $category_id = 0, $include_unset = true){

    if ($include_unset){
      $ht_status_query =       
        array(
          'relation' => 'OR',
          array(
            'key'     => '_hellotoken',
            'value'   => 'wordpress bug #23268', // requires a value on WP versions <3.9
            'compare' => 'NOT EXISTS'
          ),
          array(
            'key'   => '_hellotoken',
            'value' => $ht_state
          ),
      );
    }
    else{
      $ht_status_query = 
        array(
          array(
            'key'   => '_hellotoken',
            'value' => $ht_state
          )
      );
    }

    $args = array(
      'meta_query'  => $ht_status_query,
      'post_type'   => $post_type
    );

    if ($category_id != 0){
      $args = array_merge($args,array('cat' => $category_id));
    }

    return get_posts($args);
  }


  /**
   * Send debug code to the Javascript console
   */ 
  static function debug_to_console($data) {
    if(is_array($data) || is_object($data))
  {
    echo("<script>console.log('PHP: ".json_encode($data)."');</script>");
  } else {
    echo("<script>console.log('PHP: ".$data."');</script>");
  }
}
}

new HelloToken();
