/*!
  jQuery hellotoken Plugin 0.1

  hellotoken configuration form to manage/generate settings.
*/

;(function($)
{

  // ease of development
  var $currentHost = window.location.hostname;
  var $pluginURL = ($currentHost === 'localhost') ? 'http://localhost:3000' : 'https://hellotoken.com';

  function HTForm(el, options)
  {
    this.el = el;

    // default settings for form
    this.default_settings = {
      homepage_url: '',
      company_name: '',
      company_logo: '',
      client_id: '',
      free_content_count: 0,
      button_color: '#f7931a',
      button_text_color: '#ffffff',
      show_delay: 0,
      is_demo: 0,
      redirect_type: 0,
      redirect_url: '',
      default_enable: 1
    };

    this.options = $.extend(true, {}, {

      // settings definition for controls on the form
      settings: this.default_settings,

      // text definition in the form
      texts: {
        connect: 'Connect',
        your_homepage: 'Your Homepage',
        optional: 'Optional',
        necessary: 'Crucial for Success',
        client: 'Client ID*',
        extra: 'Some Extras Just for You',
        demo: 'Demo',
        is_demo: 'Is this site a demo?',
        question: "A burning question you'd like to ask your readers",
        question_desc: '',
        option: "Add up to 5 answer choices. Or leave it blank for a fill-in-the-blank question. Whatever floats your boat.",
        choice_a: 'Answer 1',
        choice_b: 'Answer 2',
        choice_c: 'Answer 3',
        choice_d: 'Answer 4',
        choice_e: 'Answer 5',
        company: 'Company',
        company_logo: 'Company Logo',
        please_select: 'Please select',
        free_content_count: 'Free Content Count',
        free_content_count_desc: 'Number of articles user has to click before the hellotoken dialog box is shown.',
        button_color: 'Button Color',
        button_text_color: 'Button Text Color',
        sign: '$',
        tweet_text_desc: 'Leave blank if you want to use a page title.',
        show_delay: 'Paywall show delay',
        show_delay_desc: 'Delay showing the paywall by a specified amount of time. By default the paywall is shown immediately.',
        seconds: 'second(s)',
        redirect_type: 'Redirect type',
        redirect_type_desc: 'If the user closes the modal, what would you like to do?',
        redirect0: 'Close the modal with no redirect',
        redirect1: 'Redirect to your site\'s homepage',
        redirect2: 'Redirect to a custom URL (enter the full address, in the form "http://www.customurl.com", below)',
        default_enable: 'Default post activation',
        default_enable_desc: 'Activate or deactivate hellotoken by default on new articles',
        default_enable0: 'Deactivate hellotoken by default on new articles',
        default_enable1: 'Activate hellotoken by default on new articles'
      },

      // called when form is initialized
      onInit: $.noop
    }, options);

    this.makeTemplate();

    this.options.onInit.call(this);

    this.fillOtherSettings();
  }

  // methods
  var proto = HTForm.prototype;

  // fill in all the settings that aren't nice inputs and text boxes
  proto.fillOtherSettings = function() {
    form = this;
    // checkboxes
    $("input[type='checkbox'").each(function(index, value) {
      var ele = $('#' + this.id);
      var v = ele.val();
      if(v == 1) ele.prop('checked', true);
    });

    // ONLY default activation settings radio buttons (you'll have to rewrite to add others)
    $("input[type='radio'").each(function(index, value) {
      var ele = $('#' + this.id);
      if(ele.val() == form.options.settings.default_enable) ele.prop('checked', true);
    });    
  };

  // create template and insert it into DOM
  proto.makeTemplate = function()
  {
    var texts = this.options.texts,
      template = '\
      <form class="ht-form">\
        <input type="hidden" name="htform" value="1" />\
  <h3>' + texts.necessary + '</h3>\
        <table class="ht-form-table">\
          <tr>\
            <th scope="row"><label for="ht_homepage_url">' + texts.your_homepage + '</label></th>\
            <td>\
              <input type="text" class="ht-website" name="ht_homepage_url" id="ht_homepage_url" value="" placeholder="www.yourwebsite.com" />\
            </td>\
          </tr>\
          <tr>\
            <th scope="row"><label for="ht_client_id">' + texts.client + '</label></th>\
            <td>\
              <input type="text" class="ht-website" name="ht_client_id" id="ht_client_id" value="" />\
            </td>\
          </tr>\
        </table>\
        <h3>' + texts.extra + '</h3>\
        <table class="ht-form-table">\
          <tr>\
            <th scope="row"><label for="ht_free_content_count">' + texts.free_content_count + '</label></th>\
            <td>\
              <input type="number" title="' + texts.free_content_count_desc + '" class="ht-pass" name="ht_free_content_count" id="ht_free_content_count" value="" min="0" max ="20" step="1" />\
            </td>\
          </tr>\
            <th scope="row"><label for="ht_show_delay">' + texts.show_delay + '</label></th>\
            <td>\
              <input type="number" title="' + texts.show_delay_desc + '" class="ht-pass" name="ht_show_delay" id="ht_show_delay" value="" min="0" max ="20" step="1" /> ' + texts.seconds + '\
            </td>\
          </tr>\
        </table>\
        <h3>' + texts.demo + '</h3>\
        <table class="ht-form-table">\
          <tr>\
            <th scope="row"><label for="ht_is_demo">' + texts.is_demo + '</label></th>\
            <td>\
              <input type="checkbox" title="Demo?" class="ht-demo" name="ht_is_demo" id="ht_is_demo">\
            </td>\
          </tr>\
        </table>\
        <h3>' + texts.redirect_type + '</h3>\
        <table class="ht-form-table">\
          <tr>\
            <th><label for="ht_redirect_type">' + texts.redirect_type_desc + '</label></th>\
          </tr>\
          <tr>\
            <td id="ht_redirect_container">\
              <select id="ht_redirect_type" name="ht_redirect_type" form="ht-form">\
                <option value="0">' + texts.redirect0 + '</option>\
                <option value="1">' + texts.redirect1 + '</option>\
                <option value="2">' + texts.redirect2 + '</option>\
              </select>\
              <input type="text" id="ht_redirect_url" name="ht_redirect_url" placeholder="Put custom URL here" size="84">\
            </td>\
          </tr>\
        </table>\
        <h3>' + texts.default_enable + '</h3>\
        <table class="ht-form-table">\
          <tr>\
            <td id="ht_redirect_container">\
              <form="ht-form" class="ht_default_enable" id="ht_default_enable">\
                <input type="radio" name="ht_default_enable" id="ht_radio1" value="1"><label for="ht_radio1">' + texts.default_enable1 + '</label></br>\
                <input type="radio" name="ht_default_enable" id="ht_radio0" value="0"><label for="ht_radio0">' + texts.default_enable0 + '</label></br>\
              </form>\
            </td>\
          </tr>\
        </table>\
      </form>';
 
    this.el.html(template);

    // get controls from template
    var $form = $('form', this.el);

    this.form = { this: $form }

    for(var i in this.default_settings) {
      this.form[i] = $('#ht_' + i, $form);
    }
    
    this.setSettings();
   
    // set change listener to ht_redirect_type to add additional text input if custom url
    if($('#ht_redirect_type').val() != 2){
      $('#ht_redirect_url').hide();
    }
   
    $('#ht_redirect_type').change(function() {
      if($(this).val() == 2){
        $('#ht_redirect_url').show();
      } else {
        $('#ht_redirect_url').hide();
      }
    });

    // bind controls
    // $.minicolors.defaults.control = 'wheel';

    // this.form.button_color.minicolors();
    // this.form.button_text_color.minicolors();
  }

  // set settings for controls on the form
  proto.setSettings = function(settings)
  {
    if (typeof settings !== 'object')
      settings = this.options.settings;

    for(var i in settings)
      if (i=="choices" && this.form.hasOwnProperty(i)) {

      } else if (this.form.hasOwnProperty(i)) {
        this.form[i].val(settings[i]);
      }
  }

  // get settings
  proto.getSettings = function(question)
  {
    var settings = {};

    for(var i in this.default_settings)
    {
      if (i=="question_id"){
        settings[i] = question;
      } else if (i=="choices"){
        // settings[i] = []
        // settings[i].push(this.form['choice_a'].val());
        // settings[i].push(this.form['choice_b'].val());
        // settings[i].push(this.form['choice_c'].val());
        // settings[i].push(this.form['choice_d'].val());
        // settings[i].push(this.form['choice_e'].val());

      }
      else
        settings[i] = this.form[i].val();
    }

    return settings;
  }

  proto.getClient = function()
  {
    return this.form.client_id.val();
  }

  proto.getQuestion = function()
  {
    return this.form.question.val();
  }

  // do validation of controls on the form
  proto.doValidation = function()
  {
    var errors = [];
    var that = this;

    $('input[type=text], input[type=number]', this.el).removeClass('ht-error');

    if (this.form.homepage_url.val().length == 0)
      errors.push('homepage_url');

    var free_content_count = this.form.free_content_count.val();
    if (free_content_count < 0 || isNaN(free_content_count) || free_content_count > 20)
      errors.push('free_content_count');

    var show_delay = this.form.show_delay.val();
    if (show_delay < 0 || isNaN(show_delay) || show_delay > 20)
      errors.push('show_delay');

    // Checkboxes have value checked on validation
    $("input[type='checkbox'").each(function(index, value) {
      var v;
      var ele = $('#' + this.id);

      // Switch value to checked or unchecked
      v = (ele.is(':checked')) ? 1 : 0;
      that.form[this.id.substr(3)].val(v);
    });  

    $("input[name='ht_default_enable'").each(function(index, value) {
      if (this.checked){
        that.form[this.name.substr(3)].val(this.value);
        return;
      }
    });  

    var form = this.form;
    var el = this.el;

    $.ajax({
			url: $pluginURL + "/popup/check",
      method: "GET",
      dataType: "JSONP",
      data:{
          "publisher_alpha_id": this.form.client_id.val(),
          "publisher_url": window.location.href
      },
      success: function(data){
        if (data){
          for(var i in errors)
            form[errors[i]].addClass('ht-error');

          if (errors.length > 0)
          {
            $('html, body').animate({ scrollTop: el.offset().top });
            return false;
          }
          else{
            return true;
          }
        }
        else{
          errors.push('client_id');
          for(var i in errors)
            form[errors[i]].addClass('ht-error');

          if (errors.length > 0)
          {
            $('html, body').animate({ scrollTop: el.offset().top });
            return false;
          }
        }
      },
      error: function(data){
        console.log("HT: Couldn't save data. Aborted.");
      }
    });

    return true;
  };


  // extend jquery
  $.fn.extend({
    HTForm: function(options)
    {
      // minicolors plugin is required
      // if (!$.minicolors)
      // {
      //   throw 'jQuery MiniColors is required!';
      //   return this;
      // }

      var inst = this.data('HTForm');

      // if valid instance then perform calls on the class
      if (inst && options)
      {
        if (inst[options])
          return inst[options].apply(inst, Array.prototype.slice.call(arguments, 1));

        return inst;
      }
      else
      {
        inst = new HTForm(this, options);
        this.data('HTForm', inst);
      }

      // keep chain
      return this;
    }
  });

})(jQuery);
