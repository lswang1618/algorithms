(function($)
{
    window.mobileCheck = (function()
    {
        var check = false;

        (function(a)
        {
            if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))
                check = true;
        })(navigator.userAgent||navigator.vendor||window.opera);

        return check;
    })();

    // get current URL from where is this script loaded - it's used to append CSS files correctly
    var scripts = document.getElementsByTagName('script');
    var url = "";
    for (var i = scripts.length - 1; i >= 0; i--){
      url = scripts[i].getAttribute('src');
      if (url != null && url.indexOf("hellotoken3") != -1)
        break;
    }
    ht_url = url.substr(0, url.lastIndexOf('/') + 1),
    head = document.getElementsByTagName('head')[0],
    css = [
        ht_url + 'style1.css',
        ht_url + 'mobile.css'
    ];

    for(var i in css)
    {
        if (i == 1 && !mobileCheck)
            continue;

        var link = document.createElement('link');
        link.setAttribute('href', css[i]);
        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('type', 'text/css');
        //link.setAttribute('media', '(max-width: 420px)');
        head.appendChild(link);
    }

    var currentHost = window.location.hostname;
    var pluginURL = (currentHost === 'localhost') ? 'http://localhost:3000' : 'https://hellotoken.com';


    // HT main class
    function HelloToken(params)
    {
        // Alias for original HelloToken object
        this.params = params;
        this.params.is_demo = (params.is_demo == '1') ? true : false;
        this.animatingTimerWidth = false;
        this.timer = null;
        this.checkModalTimer = null;
        this.invoiceCheckTimer = null;
        this.stopChecking = false;
 
        this.params = $.extend(true, {}, {
            // header
            company: "The hellotoken Times",
            heading: "Continue Reading with a Click",
            logo: false,
            clientID: "",
            subtitle: "You've read <span class='ht-limit' style='text-decoration: underline'>15</span> free article(s) - answer a question to keep going!",
            // useSubtitle: "Activate a pass to keep reading!",
            // currency_sign: '$',
            // yourOrderText: 'Your Order',

            // payment page
            // helpText: 'Login to your Bitcoin wallet to check out',
            // usePayPal: 'Or use PayPal',

            // footer
            footerText: "Powered by hellotoken",
            footerLink: "http://www.hellotoken.com",

            // colors
            buttonColor: '#f7931a',
            buttonTextColor: '#ffffff',

            // Modal Settings
            numberClickedNeedBuy: 15,
            articleClickRefreshRate: 7,
            showDelay: 0,

            homeLink: window.location.host,

            // if it should show ht only if tag is present - "<script type="ht"></script>"
            triggerOnTag: false,
            checkForTumblr: false, // if it should check if we are on tumblr post page
            checkForBlogger: false, // check for blogger post page

            // preview mode
            preview: false
        }, params);

        // variables saved to cookies
        var saved = false;
        try
        {
            saved = JSON.parse(this.getCookie('ht-saved'));
        } catch(e) { }

        if (!saved) saved = {};

        this.saved = $.extend({}, {
            // successful purchases
            showThanks: false,
            articleTypeIndex: 0,

            // Require to show the dialog from checking passes?
            requireShowFromCheck: null,

            // set last visited page
            redirectPage: null,

            // invoices
            invoices: [],
            currentInvoice: null,

            // routing
            successURL: null,
            articleUponClick: null
        }, saved);

        // get article passes
        try
        {
            this.articlePasses = JSON.parse(this.getCookie('ht-articlePasses'));
        }
        catch(e)
        {
            this.articlePasses = false;
        }
        if (!this.articlePasses) this.articlePasses = {};
        numQues = Object.keys(this.articlePasses).length;
        w = this;

        // Variable to show if demo is checked or not
        var popupPath = (this.params.is_demo) ? '/popup/demo' : '/popup/index';
        popupPath += '?clientID=' + this.params.clientID;

        this.htDomHTML = '\
            <div id="ht-grayOut"></div>\
            <div id="ht-dialog">\
                <iframe id="ht-iframe" src="'+ pluginURL + popupPath + '">\
            </div>';


        // output custom stylesheet for buttons
        $('<style></style>').text('\
            .ht-purchaseOption .ht-button.orange, .ht-thanksContinue {\
                background-color: ' + this.params.buttonColor + ' !important;\
                color: ' + this.params.buttonTextColor + ' !important;\
            }\
            .ht-purchaseOption .ht-button.orange:hover, .ht-thanksContinue:hover {\
                background-color: ' + this.setColorBrightness(this.params.buttonColor, 40) + ' !important;\
                color: ' + this.params.buttonTextColor + ' !important;\
            }\
        ').appendTo($('body'));

        // get currently tracked articles
        try
        {
            this.articlesTracked = JSON.parse(this.getCookie('ht-articlesTracked'));
        }
        catch(e)
        {
            this.articlesTracked = false;
        }
        if (!this.articlesTracked) this.articlesTracked = {};


        this.testingType = "default";
        this.arrivalTime = new Date();

        mixpanel.track("Visit", {
            "Client ID": this.params.clientID,
            "Domain": window.location.hostname,
            "Page": window.location.pathname,
            "Time": this.arrivalTime.toISOString(),
            "Testing type": this.testingType
        });

        var ping_img = document.createElement("img");
        ping_img.style.display = "none";
        document.body.appendChild(ping_img);
        ht = this;
        ping_img.onload = function()
        {
            console.log("HT: hellotoken.com reached. Modal loading...")
            $(ping_img).remove();
            ht.initialize();
        };
        ping_img.onerror = function(data)
        {
            console.log("HT: hellotoken.com not reachable. Dumping data:")
            console.log(data);
            $(ping_img).remove();
        }
        ping_img.src = pluginURL + "/images/ht_logo.png";

        // Get the time the person started reading the article

        // ht = this;
        // $.ajax({url: pluginURL + "/popup/ping",
        //     type: "HEAD",
        //     timeout:5000,
        //     crossDomain: true,
        //     dataType: "JSONP",
        //     complete: function (jqXHR, textStatus){
        //         console.log("HT: Ping sent to hellotoken servers.");
        //         switch (jqXHR.status){
        //         case 200: 
        //             console.log("HT: hellotoken.com reached. Modal loading...");
        //             ht.initialize();
        //             break;
        //         default:
        //             console.log("HT: hellotoken.com not reachable. Status code: "+jqXHR.status);
        //         }
        //     }
        //  });
    }

    // ----- Main Methods ----- //

    HelloToken.prototype.setColorBrightness = function(color, diff)
    {
        var rgb = [],
            c = $.trim(color);

        if (c.length != 7)
            return $c;

        for(var i = 1; i < c.length; i+=2)
            rgb.push(c[i] + c[i+1]);

        for(var i in rgb)
        {
            var dec = parseInt(rgb[i], 16);

            if (diff >= 0)
                dec += diff;
            else
                dec -= abs(diff);

            var hex = Math.max(0, Math.min(255, dec)).toString(16);
            rgb[i] = hex.length == 1?'0':'' + hex;
        }

        return '#' + rgb.join('');
    }

    HelloToken.prototype.receiveMessage = function(event){
        var path = window.location.pathname;
        if (event.origin !== pluginURL)
            return;
        // See our server code for the syntax of the data string
        if (event.data.substring(0,8) === "question"){
            // if (freeOver1 && !hasPass1 && !event.target.t.articlesTracked[path]){
            console.log("HT: Question ready on " + pluginURL + " servers.");
            try{
                var visitJSON = $.parseJSON(event.data.substring(8));
                this.testingType = visitJSON.testingType;
                // Load dialog last, since it shows dialog and tracks displaying it
                this.loadDialog(visitJSON.question.alpha_id);
            }
            catch(err){
                console.log("HT: Modal closed. Error: "+err);
            }
        }
        else if (event.data == "close"){
            var closeTime = new Date().toISOString;
            mixpanel.track("Modal Closed", {
                "Client ID": event.target.t.params.clientID,
                "Domain": window.location.hostname,
                "Page": window.location.pathname,
                "Time": new Date().toISOString(),
                "Time since arrival (seconds)": ((closeTime - this.arrivalTime) / 1000),
                "Testing type": this.testingType
            });
            switch(parseInt(this.params.redirect_type)){
              case 0:
                break;
              case 1:
                window.location.replace(this.params.homeLink);
                break;
              case 2:
                if(this.params.redirect_url.indexOf('://') > -1)
                  window.location.replace(this.params.redirect_url);
                else
                  window.location.replace("http://" + this.params.redirect_url);
                break;
            }
            
            // instead just close the modal
            $('#ht-grayOut').remove();
            $('#ht-iframe').fadeOut();
            $('#ht-dialog').fadeOut();
            $('body').css({
                'width': 'inherit',
                'height': 'inherit',
                'position': 'inherit',
                'overflow': 'visible'
            });
            console.log("HT: Close event received. Modal closed without redirect.");
        }
        else if (event.data.substring(0,13) === "close no pass"){
            $('#ht-grayOut').remove();
            $('#ht-iframe').fadeOut();
            $('#ht-dialog').fadeOut();
            $('body').css({
                'width': 'inherit',
                'height': 'inherit',
                'position': 'inherit',
                'overflow': 'visible'
            });
            console.log("HT: No questions received. Modal closed.");

        }
        else if (event.data.substring(0,6) == "answer") {
            mixpanel.track("Question Answered", {
                "Client ID": event.target.t.params.clientID,
                "Domain": window.location.hostname,
                "Page": window.location.pathname,
                "Question": event.data.substring(7),
                "Time": new Date().toISOString(),
                "Testing type": this.testingType
            });
            $('#ht-grayOut').remove();
            $('#ht-iframe').fadeOut();
            $('#ht-dialog').fadeOut();
            $('body').css({
                'width': 'inherit',
                'height': 'inherit',
                'position': 'inherit',
                'overflow': 'visible'
            });
            window.htArticlePass()
            console.log("HT: Question answered. Modal closed.")
        }
    }

    HelloToken.prototype.initialize = function(){
        // check if it should show the dialog
        if (this.params.triggerOnTag)
        {
            // don't show if there is not our tag
            if ($('script[type=ht]').length == 0){
                console.log("HT: Script not found. Modal closed.");
                return;
            }

            var url = location.href;

            // don't show when we are not on post page of tumblr or blogger
            if (this.params.checkForTumblr && !/\/post\/\d+\/.+/.test(url)){
                console.log("HT: Not on a Tumblr post page. Modal closed.");
                return;
            }

            if (this.params.checkForBlogger && !/\/\d+\/\d+\/.+/.test(url)){
                console.log("HT: Not on a Blogger post page. Modal closed.");
                return;
            }
        }

        var self = this, $body = $('body'); 
        // TODO: convert self to a useful name like "HT"...

        $body.append(this.htDomHTML);

        if ($('#ht-dialog').length > 0)
            console.log("HT: Modal successfully appended.");
        else
            console.log("HT: Modal unsuccessfully appended.");

        // Hide dialog before showing later
        $('#ht-dialog').css('display', 'none');

        // Set limit number
        $('.ht-limit').text(this.params.numberClickedNeedBuy);

        /* ----- Dialog Closing ----- */

        // To close dialog
        // I don't think this .close class actually exists...
        // but other code references triggering it, so I'd be careful
        $('#ht-dialog .close').on('click', function()
        {
            // remove invoices if dialog was closed
            // legacy: ignore
            self.saved.invoices = [];
            self.saved.currentInvoice = null;
            self.saveVars();
            self.stopChecking = true;

            // self.checkThanksAndReverse();

            if (!self.saved.requireShowFromCheck || self.params.preview)
            {
                $('body').css({
                    'width': 'inherit',
                    'height': 'inherit',
                    'position': 'inherit',
                    'overflow': 'visible'
                });

                $('#ht-grayOut').fadeOut();
                $('#ht-dialog').fadeOut();

                if (self.params.preview)
                {
                    $('#ht-grayOut').remove();
                    $('#ht-dialog').remove();
                }

                console.log("HT: X-button clicked. Pass consumed and modal closed.");
            }
            else
            {
                if (!self.articlesTracked[self.saved.redirectPage])
                    self.saved.redirectPage = null;

                // window.location = self.saved.redirectPage || self.params.homeLink;

                // console.log("HT: X-button clicked. No pass consumed, reader redirected, and modal closed.");
            
                // Allow x-out to just close dialog. TBD if permanent design decision
                $('body').css({
                    'width': 'inherit',
                    'height': 'inherit',
                    'position': 'inherit',
                    'overflow': 'visible'
                });

                $('#ht-grayOut').fadeOut();
                $('#ht-dialog').fadeOut();

                console.log("HT: X-button clicked. Modal closed without redirect.");
            }
        });

        // Close dialog upon ESC keypress
        $(document).keyup(function (e)
        {
            if (e.which == '27')
                $('#ht-dialog .close').trigger('click');
        });

        // Clicking outside modal (should this be possible..?)
        $(document).click(function(e)
        {
            var dialogShowing = $('#ht-dialog').is(':visible'),
                notDialog = $(e.target).attr('id') != "ht-dialog",
                notChildOfDialog = $(e.target).parents('#ht-dialog').length <= 0;

            // commented so clicking outside does nothing
            // if (dialogShowing && notDialog && notChildOfDialog)
            //     $('#ht-dialog .close').trigger('click');
        });

        // When not mobile, make sure div always centered
        $(window).resize(function()
        {
            self.check_body_padding_set_overlay();
            //self.set_bmd_position();
        });

        var path = window.location.pathname,
            successURL = this.saved.successURL || this.params.homeLink;

        self.redirectPage = null;
        
        // save permanent data on unload
        $(window).on('unload', function()
        {
            if (self.params.preview){
                return;
            }

            self.saved.redirectPage = location.href;
            self.saved.currentInvoice = null;
            self.saveVars();

            var exitTime = new Date();

            mixpanel.track("Page Exited", {
                "Client ID": self.params.clientID,
                "Domain": window.location.hostname,
                "Page": window.location.pathname,
                "Time": exitTime.toISOString(),
                "Time since arrival (seconds)": ((exitTime - self.arrivalTime) / 1000),
                "Testing type": self.testingType
            });
        });


        if (this.params.preview)
        {
            this.show();
            return;
        }

        // Check if success page, create passes
        if (path.indexOf(successURL) !== -1)
        {
            var query = unescape(window.location.search.split("?")[1]);

            var queryValueKey = "&order[total_native][cents]";
            var foundIndex = query.indexOf(queryValueKey);

            // If this is not returning parameters of what is paid
            if (foundIndex == -1){
                console.log("HT: Success page, but no paid parameters. Modal closed.");
                return;
            }

            var valueIndex = foundIndex + queryValueKey.length + 1;
            var endIndex = query.indexOf("&", valueIndex + queryValueKey.length + 1);
            endIndex = endIndex === -1 ? query.length - 1 : endIndex;

            var queryValue = parseFloat(query.substring(valueIndex, endIndex));

            var passLink = this.saved.articleUponClick;

            this.setPass(queryValue, passLink);
        }

        // Check to see if any passes have cleared
        for (var i in this.saved.invoices)
            if (this.saved.invoices[i] != this.saved.currentInvoice)
                this.checkInvoiceStatus(this.saved.invoices[i]);

        // // Show the outstanding invoice
        // if (this.saved.currentInvoice != null)
        //     this.checkInvoiceStatus(this.saved.currentInvoice, true);

        // track article url
        this.saved.articleUponClick = path;

        // Listen for a message from the iframe
        // anonymous function is a workaround so that function still owned by HT
        window.addEventListener("message", function(event) {self.receiveMessage(event)}, false);

        // Addd HT object to the window (used within receiveMessage)
        window.t = this;

        // article pass
        window.htArticlePass = function()
        {
            var index = self.saved.invoices.indexOf(self.saved.currentInvoice);

            if (index !== -1)
                self.saved.invoices.splice(index, 1);

            self.saved.currentInvoice = null;

            self.setPass(10);
            // This shouldn't be necessary
            // self.checkPassesAndSetTimer();
            self.saved.requireShowFromCheck = false;
            self.saveVars();
            //self.showThankYouDom(true);
            $('#ht-dialog').hide();
            $('#ht-dialog .close').trigger('click');
        }
    }

    /**
     * A function that first checks if the dialog should be loaded at all
     * and then appropriately shows the dialog.
     * The main two helper functions are thus checkPassesAndSetTimer() and show()
     * Question argument used to identify the question being shown so it can be tracked by MP.
     */
    HelloToken.prototype.loadDialog = function(question){
        var HT = this // remember the current object
        // Article location
        var path = window.location.pathname
        // Number of articles read
        var numTracked = Object.keys(this.articlesTracked).length;
        // Free reading over? (either read more articles than allowed, or none allowed at all)
        var freeOver = numTracked >= this.params.numberClickedNeedBuy || this.params.numberClickedNeedBuy < 1;
        // Does the reader have a pass aleady? (Potentially by having the article before.)
        var hasPass = this.checkPassesAndSetTimer();

        // If already exceeded in article number AND article number has returned below limit
        if (!this.articlesTracked[path] && numTracked < this.params.numberClickedNeedBuy)
        {
            // Set state to not exceeded anymore
            this.articlesTracked[path] = true;
            this.setCookie('ht-articlesTracked', JSON.stringify(this.articlesTracked), 365);
            // It seems like freeover and articlesTracked is redundant except for the cookies part...
        }
        // If free reading over AND no passes given AND article limit exceeded
        // or a demo version--
        if ((freeOver && !hasPass && !this.articlesTracked[path]) ||
            this.params.is_demo || window.location.hostname == "demo.hellotoken.com")
        {
            if (this.params.showDelay > 0)
            {
                window.setTimeout(function()
                {
                    HT.show();
                    HT.saved.requireShowFromCheck = true;
                }, HT.params.showDelay * 1000);
            }
            else
            {
                this.show();
                this.saved.requireShowFromCheck = true;
            }
 
            if (this.params.is_demo)
                console.log("HT: Demo version discovered. Modal automatically loaded.");
            else
                console.log("HT: Free articles over, but no passes found. Modal loaded.");

            mixpanel.track("Question Seen", {
                "Client ID": this.params.clientID,
                "Domain": window.location.hostname,
                "Page": window.location.pathname,
                "Question": question,
                "Time": new Date().toISOString(),
                "Testing type": this.testingType
            });
        }
        else{
            this.saved.requireShowFromCheck = false;
            if (!freeOver)
                console.log("HT: Free articles still remaining.");
            if (hasPass)
                console.log("HT: Passes still remaining.")
            // if (this.articlesTracked[path])
            //     console.log("HT: Article limit not yet passed.")
            console.log("HT: Closing modal.")
        }
    }

    // open popup window
    HelloToken.prototype.openWindow = function(url, width, height)
    {
        var left = (screen.width - width) / 2,
            top = (screen.height - height) / 2;

        window.open(url, null, 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,copyhistory=no,width=' + width + ',height=' + height + ',top=' + top + ',left=' + left);
    }


    // show ht modal dialog
    HelloToken.prototype.show = function()
    {
        this.check_body_padding_set_overlay();
        //this.set_bmd_position();
        $('#ht-grayOut').fadeIn();
        $('#ht-dialog').fadeIn();

        if($('#ht-dialog').is(':visible'))
            console.log("HT: Successfully made modal visible.");
        else
            console.log("HT: Unsuccessfully made modal visible.");

        // When modal is active, no need to scroll
        if (!this.params.preview)
        {
            $('body').css({
                'width': '100%',
                'height': '100%',
                'position': 'fixed',
                'overflow': 'hidden'
            });
        }
    }

    // ----- Helper Functions ----- //
    HelloToken.prototype.set_bmd_position = function()
    {
        var windowWidth = $(window).width(),
            windowHeight = $(window).height(),
            windowMobile = windowWidth <= 420;

        if (mobileCheck)
        {
            $('#ht-dialog').css('top', '0px');
            $('#ht-dialog').css('left', '0px');
            return;
        }

        var bmHeight = 471;
        var bmWidth = 702;

        if ($('#ht-dialog').is(":visible"))
        {
            bmHeight = $('#ht-dialog').outerHeight();
            bmWidth = $('#ht-dialog').outerWidth();
        }

        var bmTop = windowHeight / 2 - bmHeight / 2;
        bmTop = bmTop < 0 ? 0 : bmTop;
        var bmLeft = windowWidth / 2 - bmWidth / 2;
        bmLeft = bmLeft < 0 ? 0 : bmLeft;

        $('#ht-dialog').css('top', bmTop + 'px');
        $('#ht-dialog').css('left', bmLeft + 'px');
    };

    HelloToken.prototype.check_body_padding_set_overlay = function()
    {
        if (mobileCheck)
            return;

        var top = this.get_number_from_px($('body').css('margin-top'));
        var bottom = this.get_number_from_px($('body').css('margin-bottom'));
        var left = this.get_number_from_px($('body').css('margin-left'));
        var right = this.get_number_from_px($('body').css('margin-right'));

        $('#ht-grayOut').css('top', '-' + top + 'px');
        $('#ht-grayOut').css('left', '-' + left + 'px');
        $('#ht-grayOut').css('width', $(document).width() + right + 'px');
        $('#ht-grayOut').css('height', $(document).height() + bottom + 'px');
    };

    HelloToken.prototype.get_number_from_px = function(string)
    {
        var index = string.indexOf('px');
        return parseInt(string.substring(0, index));
    };

    HelloToken.prototype.encrypt = function(str)
    {
        var b = '';
        for(var i = 0; i < str.length; i++)
            b += String.fromCharCode(69 ^ str.charCodeAt(i));

        return b;
    }

    HelloToken.prototype.decrypt = function(str)
    {
        var b = '';
        for(var i = 0; i < str.length; i++)
            b += String.fromCharCode(69 ^ str.charCodeAt(i));

        return b;
    }

    // ----- Cookies ----- //
    HelloToken.prototype.setCookie = function(name, value, days)
    {
        var exp_date = new Date();
        exp_date.setDate(exp_date.getDate() + days);

        value = escape(this.encrypt(value)) + (days == null?'':'; expires=' + exp_date.toUTCString()) + '; path=/';
        document.cookie = name + "=" + value
    }

    HelloToken.prototype.getCookie = function(name)
    {
        var cookies = document.cookie.split(';');

        for(var i in cookies)
        {
            var cook = cookies[i];

            x = cook.substr(0, cook.indexOf('='));
            y = cook.substr(cook.indexOf('=') + 1);
            x = x.replace(/^\s+|\s+$/g, '');
            if(x == name)
                return this.decrypt(unescape(y));
        }

        return false;
    }


    HelloToken.prototype.checkPassesAndSetTimer = function()
    {
        if(window.location.name === 'demo.hellotoken.com' || this.params.is_demo){
          console.log('HT: On demo, so passes invalidated.');
          return false;
        }
        var href = window.location.href;
        // -- Check for article passes -- //
        var articlePasses = false;

        try
        {
            articlePasses = JSON.parse(this.getCookie('ht-articlePasses'));
        } catch(e) { }

        if (!articlePasses) articlePasses = [];

        // Any passes found?
        var foundActiveArticlePass = false;
        // Index of the first (fake) pass?
        var firstArticlePassLocation = -1;

        for (var articlePass in articlePasses)
        {
            var pass = articlePasses[articlePass];
            // If a pass was found for this specific url (page)
            if (pass.link == href)
            {
                // Activate the pass if not so already
                // Right now we don't care if it's been activated or not
                // so a pass for an article is permanent
                if (!pass.activated)
                    pass.activated = true;

                // TODO TESTING check if article passes has updated
                this.setCookie('ht-articlePasses', JSON.stringify(articlePasses), 365);
                foundActiveArticlePass = true;

                // Return that a pass has been found
                console.log("HT: Searching for article passes...found a pass for this article.");
                return true;
            }
            // Otherwise, if the pass has no link or activation status, and we haven't found such a pass yet
            // "such" passes are probably the "new" ones that are being sent in the popup code
            else if ((!pass.activated || !pass.link) && firstArticlePassLocation == -1)
                firstArticlePassLocation = articlePass;

        }

        // No (real) active passes were found at all
        if (!foundActiveArticlePass)
        {
            // If we found one of those "fake" passes
            if (firstArticlePassLocation != -1)
            {
                if (!this.saved.articleUponClick)
                {
                    // alert('wtf?');
                    // debugger;
                }

                // Set the link and activation for that fake pass
                articlePasses[firstArticlePassLocation].link = this.saved.articleUponClick;
                articlePasses[firstArticlePassLocation].activated = true;

                // Set that we actually found a fake pass
                foundActiveArticlePass = true;

                // Save article pass state to cookie
                this.setCookie('ht-articlePasses', JSON.stringify(articlePasses), 365);

                // Return that a pass was found
                console.log("HT: Searching for article passes...found an artificial pass for this article.");
                return true;
            }
            else{
                console.log("HT: Searching for article passes...no valid article passes found.");
                return false;
            }
        }

        // This should never hit
        return (foundActiveArticlePass);
    }

    HelloToken.prototype.setPass = function(passPrice, passLink)
    {
        // -- Article Pass -- //

        // Create and Add new pass
        var articlePasses = false;

        try
        {
            articlePasses = JSON.parse(this.getCookie('ht-articlePasses'));
        } catch(e) { }

        if (!articlePasses) articlePasses = [];

        var newPass = {
            link: window.location.href,
            activated: false // Allow this pass to be used once for another article
        };

        articlePasses.push(newPass);

        // Save article pass state to cookie
        this.setCookie('ht-articlePasses', JSON.stringify(articlePasses), 365);

        this.saved.showThanks = true;
        this.saved.articleTypeIndex = 0;

        this.saveVars();

        // Redirect after pass setting; commented for now
        // if (passLink !== undefined)
        //     window.location = passLink || ht.homeLink;
    }

    HelloToken.prototype.saveVars = function()
    {
        this.setCookie("ht-saved", JSON.stringify(this.saved), 30);
    }


    // extend jquery 
    $.extend({
        HelloToken: function(params)
        {
            return new HelloToken(params);
        },
        HT: function(params)
        {
            return new HelloToken(params);
        }
    });

})(jQuery);
